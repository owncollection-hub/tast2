const header = document.querySelector('.site-header');
const menuButton = document.querySelector('.menu-button');
const mainNav = document.querySelector('.main-nav');

window.addEventListener('scroll', () => {
  header.classList.toggle('scrolled', window.scrollY > 20);
});

menuButton.addEventListener('click', () => {
  const isOpen = mainNav.classList.toggle('open');
  menuButton.classList.toggle('active', isOpen);
  menuButton.setAttribute('aria-expanded', String(isOpen));
  menuButton.setAttribute('aria-label', isOpen ? '메뉴 닫기' : '메뉴 열기');
});

mainNav.querySelectorAll('a').forEach((link) => link.addEventListener('click', () => {
  mainNav.classList.remove('open');
  menuButton.classList.remove('active');
  menuButton.setAttribute('aria-expanded', 'false');
}));

const revealObserver = new IntersectionObserver((entries) => {
  entries.forEach((entry) => {
    if (entry.isIntersecting) {
      entry.target.classList.add('visible');
      revealObserver.unobserve(entry.target);
    }
  });
}, { threshold: 0.14 });

document.querySelectorAll('.reveal').forEach((element) => revealObserver.observe(element));

const counterObserver = new IntersectionObserver((entries) => {
  entries.forEach((entry) => {
    if (!entry.isIntersecting) return;
    const counter = entry.target;
    const target = Number(counter.dataset.target);
    const start = performance.now();
    const duration = 1200;
    const update = (now) => {
      const progress = Math.min((now - start) / duration, 1);
      counter.textContent = Math.floor(target * (1 - Math.pow(1 - progress, 3)));
      if (progress < 1) requestAnimationFrame(update);
    };
    requestAnimationFrame(update);
    counterObserver.unobserve(counter);
  });
}, { threshold: 0.7 });

document.querySelectorAll('.counter').forEach((counter) => counterObserver.observe(counter));

document.querySelectorAll('.faq-item button').forEach((button) => {
  button.addEventListener('click', () => {
    const item = button.closest('.faq-item');
    const shouldOpen = !item.classList.contains('open');
    document.querySelectorAll('.faq-item').forEach((faq) => {
      faq.classList.remove('open');
      faq.querySelector('button').setAttribute('aria-expanded', 'false');
    });
    if (shouldOpen) {
      item.classList.add('open');
      button.setAttribute('aria-expanded', 'true');
    }
  });
});

const caseData = {
  customer: {
    icon: '◎', label: 'CUSTOMER CARE', title: '기다림 없는 고객 경험',
    text: '반복 문의는 빠르게 해결하고, 섬세한 판단이 필요한 순간에는 담당자에게 대화 맥락과 함께 연결합니다.',
    items: ['문의 자동 분류 및 답변', '상담원 스마트 연결', '실시간 감정 분석'], stat: '고객 만족도 4.9'
  },
  sales: {
    icon: '↗', label: 'SALES ASSISTANT', title: '기회를 놓치지 않는 세일즈',
    text: '방문자의 관심사를 실시간으로 파악하고 가장 알맞은 상품과 콘텐츠를 제안해 구매 결정을 돕습니다.',
    items: ['잠재 고객 자동 발굴', '개인화 상품 추천', '상담 예약 연결'], stat: '전환율 42% 향상'
  },
  team: {
    icon: '✦', label: 'WORK ASSISTANT', title: '찾는 시간은 줄이고, 몰입은 더하고',
    text: '흩어진 사내 문서와 업무 지식을 하나로 연결해, 팀원이 질문하는 순간 정확한 정보를 찾아줍니다.',
    items: ['사내 지식 통합 검색', '업무 문서 요약', '반복 요청 자동화'], stat: '검색 시간 68% 감소'
  }
};

const casePanel = document.querySelector('#case-panel');
document.querySelectorAll('.case-tab').forEach((tab) => {
  tab.addEventListener('click', () => {
    document.querySelectorAll('.case-tab').forEach((item) => {
      item.classList.remove('active');
      item.setAttribute('aria-selected', 'false');
    });
    tab.classList.add('active');
    tab.setAttribute('aria-selected', 'true');
    const data = caseData[tab.dataset.case];
    casePanel.animate([{ opacity: .25, transform: 'translateY(8px)' }, { opacity: 1, transform: 'none' }], { duration: 320 });
    casePanel.querySelector('.case-icon').textContent = data.icon;
    casePanel.querySelector('.case-label').textContent = data.label;
    casePanel.querySelector('h3').textContent = data.title;
    casePanel.querySelector('p:not(.case-label)').textContent = data.text;
    casePanel.querySelector('ul').innerHTML = data.items.map((item) => `<li>${item}</li>`).join('');
    casePanel.querySelector('.mini-chart b').textContent = data.stat;
  });
});

const demoModal = document.querySelector('#demo-modal');
const demoTrigger = document.querySelector('#demo-trigger');
const openModal = () => {
  demoModal.classList.add('open');
  demoModal.setAttribute('aria-hidden', 'false');
  demoModal.querySelector('.modal-close').focus();
};
const closeModal = () => {
  demoModal.classList.remove('open');
  demoModal.setAttribute('aria-hidden', 'true');
  demoTrigger.focus();
};
demoTrigger.addEventListener('click', openModal);
demoModal.querySelectorAll('[data-close]').forEach((button) => button.addEventListener('click', closeModal));
document.addEventListener('keydown', (event) => {
  if (event.key === 'Escape' && demoModal.classList.contains('open')) closeModal();
});

const chatForm = document.querySelector('#chat-form');
const chatInput = document.querySelector('#chat-input');
const chatBody = document.querySelector('#chat-body');
const typing = document.querySelector('#typing');

chatForm.addEventListener('submit', (event) => {
  event.preventDefault();
  const text = chatInput.value.trim();
  if (!text) return;
  const userMessage = document.createElement('div');
  userMessage.className = 'message user';
  userMessage.textContent = text;
  chatBody.appendChild(userMessage);
  chatInput.value = '';
  typing.classList.add('show');
  chatBody.appendChild(typing);
  chatBody.scrollTop = chatBody.scrollHeight;

  window.setTimeout(() => {
    typing.classList.remove('show');
    const botMessage = document.createElement('div');
    botMessage.className = 'message bot';
    botMessage.textContent = '좋은 질문이에요. 담당 팀의 상황에 맞춰 가장 효과적인 방법부터 함께 찾아볼게요. ✦';
    chatBody.appendChild(botMessage);
    chatBody.scrollTop = chatBody.scrollHeight;
  }, 900);
});

const contactForm = document.querySelector('#contact-form');
const formStatus = document.querySelector('#form-status');
contactForm.addEventListener('submit', (event) => {
  event.preventDefault();
  if (!contactForm.checkValidity()) {
    formStatus.textContent = '이름과 올바른 이메일을 입력해주세요.';
    contactForm.reportValidity();
    return;
  }
  const button = contactForm.querySelector('button');
  button.disabled = true;
  button.textContent = '신청 완료 ✓';
  formStatus.textContent = '감사합니다. 곧 Soul-G 팀이 연락드릴게요.';
  contactForm.reset();
  window.setTimeout(() => {
    button.disabled = false;
    button.innerHTML = '무료 상담 신청 <span>→</span>';
  }, 3500);
});
